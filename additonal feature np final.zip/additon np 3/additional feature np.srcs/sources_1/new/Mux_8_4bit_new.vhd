library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Mux_8_4bit is
    Port ( A0, A1, A2, A3, A4, A5, A6, A7 : in STD_LOGIC_VECTOR (3 downto 0);
           Sel : in STD_LOGIC_VECTOR (2 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end Mux_8_4bit;

architecture Behavioral of Mux_8_4bit is
begin
    -- Using a 'with-select' statement for optimal LUT mapping
    with Sel select
        Y <= A0 when "000",
             A1 when "001",
             A2 when "010",
             A3 when "011",
             A4 when "100",
             A5 when "101",
             A6 when "110",
             A7 when "111",
             "0000" when others;
end Behavioral;