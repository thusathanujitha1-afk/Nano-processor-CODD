
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;





entity Tri_State_buffer_4bit is
       Port (   I : in STD_LOGIC_VECTOR (3 downto 0);
                EN : in STD_LOGIC;
                M : out STD_LOGIC_VECTOR (3 downto 0));
end Tri_State_buffer_4bit;

architecture Behavioral of Tri_State_buffer_4bit is

begin
    process (I,EN)
      begin
        if EN = '1' then
            M <= I;
        else 
            M <= "ZZZZ";
        end if;
      end process; 

end Behavioral;
