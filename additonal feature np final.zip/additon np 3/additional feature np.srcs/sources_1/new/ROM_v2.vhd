library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.all;

entity ROM_v2 is          
      Port ( Memory_Sel: in STD_LOGIC_VECTOR(3 downto 0);
             Instruction_bus: out STD_LOGIC_VECTOR(13 downto 0));
end ROM_v2;

architecture Behavioral of ROM_v2 is

    -- Array size set to 16 to match the 4-bit Memory_Sel (0 to 15)
    type rom_type is array(0 to 15) of STD_LOGIC_VECTOR(13 downto 0);
    signal proc_ROM : rom_type := ( 
                "00100010000011", --  MOVI R1, 3  (R1 = 3)
                "00001110010000",  -- R7=R7+R1     R7=3
                "01011110010000", -- MULT R7, R1 (R7 =9
                
                -- XOR  (R7,R1)    0011 1001 ->1010 (10)
                "10001110010000",
                
                --AND R7 and R1     1010 and 0011   0010  r7=2
                "01101110010000", 
               
                -- OR R7 and R1     0010  or 0011 -> 0011 R7=3
                "01111110010000",
     
                "01000100000001", -- movi R2 ,1 R2=1
                   
                "01001110100000", -- comperator  R7 & R2  less
                
                "00110000001000", --JZR
                
        
                
                
              
                others => (others => '0') -- Fill the rest with zeros
                    );
begin

    Instruction_bus <= proc_ROM(to_integer(unsigned(Memory_Sel)));

end Behavioral
;