library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity multiplier_2 is
    port ( 
        A : in  STD_LOGIC_VECTOR (1 downto 0);
        B : in  STD_LOGIC_VECTOR (1 downto 0);
        Y : out STD_LOGIC_VECTOR (3 downto 0)
    );
end multiplier_2;

architecture Dataflow of multiplier_2 is
    -- Internal signals for partial products
    signal p0, p1, p2, p3 : STD_LOGIC;
begin
    -- Logic for a 2x2 binary multiplier
    -- Y0 = A0 AND B0
    Y(0) <= A(0) and B(0);

    -- Y1 = (A1 AND B0) XOR (A0 AND B1)
    Y(1) <= (A(1) and B(0)) xor (A(0) and B(1));

    -- Y2 and Y3 handle the carries of the partial products
    -- Y2 = (A1 AND B1) XOR ((A1 AND B0) AND (A0 AND B1))
    Y(2) <= (A(1) and B(1)) xor ((A(1) and B(0)) and (A(0) and B(1)));

    -- Y3 = (A1 AND B1) AND (A1 AND B0) AND (A0 AND B1)
    Y(3) <= (A(1) and B(1)) and (A(1) and B(0)) and (A(0) and B(1));

end Dataflow;