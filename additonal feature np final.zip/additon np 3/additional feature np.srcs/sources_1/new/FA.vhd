


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity FA is
    Port ( A : in STD_LOGIC;
           B : in STD_LOGIC;
           C_in : in STD_LOGIC;
           S : out STD_LOGIC;
           C_out : out STD_LOGIC);
end FA;

architecture Behavioral of FA is
begin
    -- Direct logic implementation
    -- Sum logic: XORing all three inputs
    S <= A XOR B XOR C_in;
    
    -- Carry out logic: Majority function
    -- Optimized to calculate in parallel with the Sum
    C_out <= (A AND B) OR (C_in AND (A XOR B));
end Behavioral;
