library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Program_Counter is
    Port ( input  : in  STD_LOGIC_VECTOR (2 downto 0); -- Next address from 3-bit Mux
           output : out STD_LOGIC_VECTOR (2 downto 0); -- Current address to ROM
           Clk    : in  STD_LOGIC;                    -- From Slow_Clk
           Reset  : in  STD_LOGIC);                   -- System Reset
end Program_Counter;

architecture Behavioral of Program_Counter is

    -- Component declaration for your D Flip-Flop
    component D_FF
        port ( D    : in  STD_LOGIC;
               Res  : in  STD_LOGIC;
               Clk  : in  STD_LOGIC;
               Q    : out STD_LOGIC;
               Qbar : out STD_LOGIC);
    end component;

begin

    -- Instantiating 3 D Flip-Flops to store the 3-bit address
    
    -- Bit 0
    D_FF_0 : D_FF
        port map(
            D   => input(0),
            Res => Reset,
            Clk => Clk,
            Q   => output(0)
        );            

    -- Bit 1
    D_FF_1 : D_FF
        port map(
            D   => input(1),
            Res => Reset,
            Clk => Clk,
            Q   => output(1)
        );
         
    -- Bit 2
    D_FF_2 : D_FF
       port map(
            D   => input(2),
            Res => Reset,
            Clk => Clk,
            Q   => output(2)
        );

end Behavioral;