library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Adder_3bit is
    Port ( input  : in  STD_LOGIC_VECTOR (2 downto 0);
           output : out STD_LOGIC_VECTOR (2 downto 0);
           C_out  : out STD_LOGIC);
end Adder_3bit;

architecture Behavioral of Adder_3bit is

    -- Component declaration for a Full Adder
    component FA
        port ( A    : in  STD_LOGIC;
               B    : in  STD_LOGIC;
               C_in : in  STD_LOGIC;
               S    : out STD_LOGIC;
               C_out: out STD_LOGIC);
    end component;

    signal carry : STD_LOGIC_VECTOR (2 downto 0);

begin
    -- To increment by 1, we add "001" to the input.
    -- This is done by setting the first Full Adder's B to '1' and others to '0'.
    
    FA_0 : FA
        port map (
            A     => input(0),
            B     => '1',      -- Adding 1 here
            C_in  => '0',      -- Initial carry is 0
            S     => output(0),
            C_out => carry(0)
        );

    FA_1 : FA
        port map (
            A     => input(1),
            B     => '0',
            C_in  => carry(0),
            S     => output(1),
            C_out => carry(1)
        );

    FA_2 : FA
        port map (
            A     => input(2),
            B     => '0',
            C_in  => carry(1),
            S     => output(2),
            C_out => C_out     -- Final carry out
        );

end Behavioral;