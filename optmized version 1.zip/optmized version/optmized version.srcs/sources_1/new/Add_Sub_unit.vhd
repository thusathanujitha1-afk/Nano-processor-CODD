----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/02/2025 04:14:38 PM
-- Design Name: 
-- Module Name: Add_Sub_unit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Add_Sub_unit is
 Port ( 
            A : in STD_LOGIC_VECTOR (3 downto 0);
            B : in STD_LOGIC_VECTOR (3 downto 0);
            M : in STD_LOGIC;
            C_out : out STD_LOGIC;
            S : out STD_LOGIC_VECTOR (3 downto 0); 
            Zero : out STD_LOGIC;
            overflow : out STD_LOGIC);
            
end Add_Sub_unit;

architecture Behavioral of Add_Sub_unit is
    component RCA_4
        port ( A0, A1, A2, A3 : in STD_LOGIC;
               B0, B1, B2, B3 : in STD_LOGIC;
               C_in : in STD_LOGIC;
               S0, S1, S2, S3 : out STD_LOGIC;
               C_out : out STD_LOGIC);
    end component;
    
    signal z : STD_LOGIC_VECTOR(3 downto 0); -- Simplified z signals
    signal carry : std_logic;
    signal S_internal : STD_LOGIC_VECTOR (3 downto 0);
    
begin
    -- 2's complement control: If M=1, bits are inverted
    z(0) <= B(0) XOR M;
    z(1) <= B(1) XOR M;
    z(2) <= B(2) XOR M;
    z(3) <= B(3) XOR M;

    RCA_4_0: RCA_4
        port map(  
                 A0 => A(0), A1 => A(1), A2 => A(2), A3 => A(3),
                 B0 => z(0), B1 => z(1), B2 => z(2), B3 => z(3),
                 C_in => M,  -- M acts as the +1 for 2's complement
                 S0 => S_internal(0),
                 S1 => S_internal(1),
                 S2 => S_internal(2),
                 S3 => S_internal(3),
                 C_out => carry);
      
    S <= S_internal;
    C_out <= carry;
    
    -- Optimized Zero Flag: High if result is 0000
    Zero <= '1' when S_internal = "0000" else '0';
    
    -- Corrected Overflow Flag:
    -- Overflow = (A_sign is same as B_sign) AND (Result_sign is different)
    -- In your code, z(3) is the effective sign of the second operand.
    Overflow <= (NOT(A(3) XOR z(3))) AND (A(3) XOR S_internal(3));

end Behavioral;