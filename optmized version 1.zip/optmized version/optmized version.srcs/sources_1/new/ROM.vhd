library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all; 

entity ROM is
    Port ( address : in STD_LOGIC_VECTOR (2 downto 0);
           instruction_code : out STD_LOGIC_VECTOR (11 downto 0));
end ROM;

architecture Behavioral of ROM is

type rom_type is array (0 to 7) of std_logic_vector(11 downto 0);
 
signal twelveSegmant_ROM : rom_type := (  -- Program is hardcoded here.


-- TASK 02 : Write an Assembly program to calculate the total of all integers between 1 and 3
    
    "100010000001", --0 Movi R1, 1
    "100100000010", --1 Movi R2, 2
    "001110010000", --2 Add  R7, R1
    "001110100000", --3 Add  R7, R2
    "100110000011", --4 Movi R3, 3
    "001110110000", --5 Add  R7, R3
    "110000000110", -- 6 JZR  R0, 6  <-- This jumps to itself (Address 6)
    "000000000000"  --7 

);

begin

instruction_code <= twelveSegmant_ROM(to_integer(unsigned(address)));

end Behavioral;