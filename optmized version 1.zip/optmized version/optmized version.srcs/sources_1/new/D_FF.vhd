library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity D_FF is
    Port ( D : in STD_LOGIC;       -- Data input
           Res : in STD_LOGIC;     -- Reset input
           Clk : in STD_LOGIC;     -- Clock input
           Q : out STD_LOGIC;      -- Data output
           Qbar : out STD_LOGIC);  -- Inverted data output
end D_FF;

architecture Behavioral of D_FF is
begin
    process (Clk)
    begin
        if rising_edge(Clk) then
            if Res = '1' then
                Q <= '0';
                Qbar <= '1';
            else
                Q <= D;
                Qbar <= not D;
            end if;
        end if;
    end process;
end Behavioral;