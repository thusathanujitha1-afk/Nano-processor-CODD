library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Design Entity for a 2-way 3-bit Multiplexer
entity Mux_2_3bit is
    Port ( A1  : in  STD_LOGIC_VECTOR (2 downto 0); -- Input Bus 1
           A2  : in  STD_LOGIC_VECTOR (2 downto 0); -- Input Bus 2
           Sel : in  STD_LOGIC;                    -- Selection Line
           Q   : out STD_LOGIC_VECTOR (2 downto 0));-- Output Bus
end Mux_2_3bit;

architecture Behavioral of Mux_2_3bit is
begin
    -- Behavioral Multiplexer Logic
    -- When Sel is '0', Q gets A1. When Sel is '1', Q gets A2.
    Q <= A1 when (Sel = '0') else A2;

end Behavioral;