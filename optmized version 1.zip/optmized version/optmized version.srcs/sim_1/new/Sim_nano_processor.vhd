library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Sim_nano_processor is
-- Testbench has no ports
end Sim_nano_processor;

architecture Behavioral of Sim_nano_processor is
    
    component Nano_processor
        Port (
            Reset         : in STD_LOGIC;
            Clk           : in STD_LOGIC;
            Output        : out STD_LOGIC_VECTOR(3 downto 0);
            Flag_overflow : out STD_LOGIC;
            Flag_Zero     : out STD_LOGIC;
            Flag_C_out    : out STD_LOGIC;
            Flag_Sign     : out STD_LOGIC;
            AnodeSelector : out STD_LOGIC_VECTOR(3 downto 0);
            S_7Seg        : out STD_LOGIC_VECTOR(6 downto 0)
        );
    end component;

    signal tb_Reset         : STD_LOGIC := '1';
    signal tb_Clk           : STD_LOGIC := '0';
    signal tb_Output        : STD_LOGIC_VECTOR(3 downto 0);
    signal tb_Flag_overflow : STD_LOGIC;
    signal tb_Flag_Zero     : STD_LOGIC;
    signal tb_Flag_C_out    : STD_LOGIC;
    signal tb_Flag_Sign     : STD_LOGIC;
    signal tb_AnodeSelector : STD_LOGIC_VECTOR(3 downto 0);
    signal tb_S_7Seg        : STD_LOGIC_VECTOR(6 downto 0);

    -- 100MHz clock period
    constant CLK_PERIOD : time := 10 ns;

begin

    uut: Nano_processor
        port map (
            Reset         => tb_Reset,
            Clk           => tb_Clk,
            Output        => tb_Output,
            Flag_overflow => tb_Flag_overflow,
            Flag_Zero     => tb_Flag_Zero,
            Flag_C_out    => tb_Flag_C_out,
            Flag_Sign     => tb_Flag_Sign,
            AnodeSelector => tb_AnodeSelector,
            S_7Seg        => tb_S_7Seg
        );

    -- Clock Generation
    clk_process : process
    begin
        tb_Clk <= '0';
        wait for CLK_PERIOD/2;
        tb_Clk <= '1';
        wait for CLK_PERIOD/2;
    end process;

    -- Stimulus Process
    stim_proc: process
    begin
        -- 1. Reset Phase
        tb_Reset <= '1';
        wait for 100 ns;
        tb_Reset <= '0';
        
        -- 2. Execution Phase
        -- Your ROM performs 6 operations before reaching the infinite loop at address 6.
        -- If your Slow_Clk divides the 100MHz clock significantly, you must increase this wait time.
        wait for 5000 ns; 

        -- 3. Verification
        -- The sum of 1+2+3 is 6 ("0110" in binary).
        if (tb_Output = "0110") then
            report "Calculation Success: Output is 6 (1+2+3)" severity note;
        else
            report "Calculation Error: Expected 0110" severity error;
        end if;

        wait;
    end process;

end Behavioral;